from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

PROJECT_ROOT = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    """Runtime settings loaded from environment variables and an optional .env file."""

    model_config = SettingsConfigDict(
        env_file=PROJECT_ROOT / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    app_env: str = "development"
    openai_api_key: str | None = None
    openai_chat_model: str = "gpt-4o-mini"
    openai_timeout_seconds: float = 45.0
    openai_max_retries: int = 2

    langsmith_tracing: bool = False
    langsmith_api_key: str | None = None
    langsmith_project: str = "etihad-local-mvp"

    jwt_secret: str = "development-only-change-me-32-bytes-minimum"
    access_token_minutes: int = 480
    database_path: Path = Field(default=Path("data/app.db"))
    audit_log_path: Path = Field(default=Path("logs/audit.jsonl"))
    policy_corpus_path: Path = Field(
        default=Path("data/corpus/etihad_hub_policy_library.json")
    )

    demo_user_username: str = "user"
    demo_user_password: str = "user-change-me"
    demo_admin_username: str = "admin"
    demo_admin_password: str = "admin-change-me"

    aviationstack_api_key: str | None = None
    aviationstack_timeout_seconds: float = 10.0
    enable_live_flight_data: bool = True

    def absolute_path(self, value: Path) -> Path:
        return value if value.is_absolute() else PROJECT_ROOT / value

    @property
    def db_file(self) -> Path:
        return self.absolute_path(self.database_path)

    @property
    def audit_file(self) -> Path:
        return self.absolute_path(self.audit_log_path)

    @property
    def corpus_file(self) -> Path:
        return self.absolute_path(self.policy_corpus_path)


@lru_cache
def get_settings() -> Settings:
    return Settings()
