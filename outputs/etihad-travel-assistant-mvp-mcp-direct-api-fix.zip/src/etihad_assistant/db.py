from __future__ import annotations

import json
import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

from pwdlib import PasswordHash

from .config import Settings
from .schemas import Role, UserPrincipal

password_hash = PasswordHash.recommended()


class Database:
    """Small SQLite persistence layer for the local MVP."""

    def __init__(self, settings: Settings):
        self.path = settings.db_file
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.settings = settings

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        try:
            yield connection
            connection.commit()
        finally:
            connection.close()

    def initialize(self) -> None:
        with self.connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS users (
                    id TEXT PRIMARY KEY,
                    username TEXT UNIQUE NOT NULL,
                    password_hash TEXT NOT NULL,
                    role TEXT NOT NULL CHECK (role IN ('user', 'admin')),
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS conversations (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL REFERENCES users(id),
                    state_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS messages (
                    id TEXT PRIMARY KEY,
                    conversation_id TEXT NOT NULL REFERENCES conversations(id),
                    role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
                    content TEXT NOT NULL,
                    payload_json TEXT,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS feedback (
                    id TEXT PRIMARY KEY,
                    answer_id TEXT NOT NULL,
                    user_id TEXT NOT NULL REFERENCES users(id),
                    rating INTEGER NOT NULL CHECK (rating IN (-1, 1)),
                    reason_code TEXT,
                    free_text TEXT,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS llm_calls (
                    id TEXT PRIMARY KEY,
                    timestamp_utc TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    conversation_id TEXT NOT NULL,
                    turn_id TEXT NOT NULL,
                    agent_name TEXT NOT NULL,
                    provider TEXT NOT NULL,
                    model TEXT NOT NULL,
                    provider_request_id TEXT,
                    prompt_version TEXT NOT NULL,
                    input_tokens INTEGER,
                    output_tokens INTEGER,
                    cached_input_tokens INTEGER,
                    reasoning_tokens INTEGER,
                    latency_ms REAL NOT NULL,
                    status TEXT NOT NULL,
                    error_type TEXT
                );
                CREATE TABLE IF NOT EXISTS policy_answer_cache (
                    cache_key TEXT PRIMARY KEY,
                    answer_json TEXT NOT NULL,
                    source_ids_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    hit_count INTEGER NOT NULL DEFAULT 0
                );
                """
            )
        self._seed_user(
            self.settings.demo_user_username,
            self.settings.demo_user_password,
            Role.user,
        )
        self._seed_user(
            self.settings.demo_admin_username,
            self.settings.demo_admin_password,
            Role.admin,
        )

    def _seed_user(self, username: str, password: str, role: Role) -> None:
        with self.connect() as conn:
            exists = conn.execute("SELECT id FROM users WHERE username = ?", (username,)).fetchone()
            if exists:
                return
            conn.execute(
                "INSERT INTO users VALUES (?, ?, ?, ?, ?)",
                (
                    str(uuid4()),
                    username,
                    password_hash.hash(password),
                    role.value,
                    datetime.now(UTC).isoformat(),
                ),
            )

    def authenticate(self, username: str, password: str) -> UserPrincipal | None:
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        if not row or not password_hash.verify(password, row["password_hash"]):
            return None
        return UserPrincipal(id=row["id"], username=row["username"], role=Role(row["role"]))

    def get_user(self, user_id: str) -> UserPrincipal | None:
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        if not row:
            return None
        return UserPrincipal(id=row["id"], username=row["username"], role=Role(row["role"]))

    def load_or_create_conversation(
        self, conversation_id: str | None, user_id: str
    ) -> tuple[str, dict[str, Any]]:
        now = datetime.now(UTC).isoformat()
        with self.connect() as conn:
            if conversation_id:
                row = conn.execute(
                    "SELECT state_json FROM conversations WHERE id = ? AND user_id = ?",
                    (conversation_id, user_id),
                ).fetchone()
                if row:
                    return conversation_id, json.loads(row["state_json"])
            new_id = str(uuid4())
            conn.execute(
                "INSERT INTO conversations VALUES (?, ?, '{}', ?, ?)",
                (new_id, user_id, now, now),
            )
        return new_id, {}

    def save_conversation_state(self, conversation_id: str, state: dict[str, Any]) -> None:
        with self.connect() as conn:
            conn.execute(
                "UPDATE conversations SET state_json = ?, updated_at = ? WHERE id = ?",
                (json.dumps(state), datetime.now(UTC).isoformat(), conversation_id),
            )

    def add_message(
        self,
        conversation_id: str,
        role: str,
        content: str,
        payload: dict[str, Any] | None = None,
        message_id: str | None = None,
    ) -> str:
        item_id = message_id or str(uuid4())
        with self.connect() as conn:
            conn.execute(
                "INSERT INTO messages VALUES (?, ?, ?, ?, ?, ?)",
                (
                    item_id,
                    conversation_id,
                    role,
                    content,
                    json.dumps(payload) if payload else None,
                    datetime.now(UTC).isoformat(),
                ),
            )
        return item_id

    def add_feedback(
        self,
        answer_id: str,
        user_id: str,
        rating: int,
        reason_code: str | None,
        free_text: str | None,
    ) -> str:
        feedback_id = str(uuid4())
        with self.connect() as conn:
            conn.execute(
                "INSERT INTO feedback VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    feedback_id,
                    answer_id,
                    user_id,
                    rating,
                    reason_code,
                    free_text,
                    datetime.now(UTC).isoformat(),
                ),
            )
        return feedback_id

    def answer_belongs_to_user(self, answer_id: str, user_id: str) -> bool:
        with self.connect() as conn:
            row = conn.execute(
                """
                SELECT 1
                FROM messages m
                JOIN conversations c ON c.id = m.conversation_id
                WHERE m.id = ? AND m.role = 'assistant' AND c.user_id = ?
                """,
                (answer_id, user_id),
            ).fetchone()
        return row is not None

    def log_llm_call(self, record: dict[str, Any]) -> None:
        columns = [
            "id",
            "timestamp_utc",
            "user_id",
            "conversation_id",
            "turn_id",
            "agent_name",
            "provider",
            "model",
            "provider_request_id",
            "prompt_version",
            "input_tokens",
            "output_tokens",
            "cached_input_tokens",
            "reasoning_tokens",
            "latency_ms",
            "status",
            "error_type",
        ]
        values = [record.get(column) for column in columns]
        with self.connect() as conn:
            conn.execute(
                f"INSERT INTO llm_calls ({', '.join(columns)}) VALUES ({', '.join('?' for _ in columns)})",
                values,
            )

    def list_llm_calls(self, limit: int = 100) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM llm_calls ORDER BY timestamp_utc DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(row) for row in rows]

    def get_cached_policy_answer(self, cache_key: str) -> dict[str, Any] | None:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT answer_json, source_ids_json FROM policy_answer_cache WHERE cache_key = ?",
                (cache_key,),
            ).fetchone()
            if row:
                conn.execute(
                    "UPDATE policy_answer_cache SET hit_count = hit_count + 1 WHERE cache_key = ?",
                    (cache_key,),
                )
        if row is None:
            return None
        return {
            "draft": json.loads(row["answer_json"]),
            "source_ids": json.loads(row["source_ids_json"]),
        }

    def put_cached_policy_answer(
        self, cache_key: str, draft: dict[str, Any], source_ids: list[str]
    ) -> None:
        with self.connect() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO policy_answer_cache
                    (cache_key, answer_json, source_ids_json, created_at)
                VALUES (?, ?, ?, ?)
                """,
                (
                    cache_key,
                    json.dumps(draft, ensure_ascii=False),
                    json.dumps(source_ids),
                    datetime.now(UTC).isoformat(),
                ),
            )

    def admin_dashboard(self, recent_limit: int = 100) -> dict[str, Any]:
        with self.connect() as conn:
            llm_totals = dict(
                conn.execute(
                    """
                    SELECT
                        COUNT(*) AS total_calls,
                        SUM(CASE WHEN status = 'ok' THEN 1 ELSE 0 END) AS successful_calls,
                        SUM(CASE WHEN status != 'ok' THEN 1 ELSE 0 END) AS failed_calls,
                        COALESCE(SUM(input_tokens), 0) AS input_tokens,
                        COALESCE(SUM(output_tokens), 0) AS output_tokens,
                        COALESCE(SUM(cached_input_tokens), 0) AS cached_input_tokens,
                        COALESCE(SUM(reasoning_tokens), 0) AS reasoning_tokens,
                        COALESCE(AVG(latency_ms), 0) AS average_latency_ms
                    FROM llm_calls
                    """
                ).fetchone()
            )
            by_model = [
                dict(row)
                for row in conn.execute(
                    """
                    SELECT model, COUNT(*) AS calls,
                           COALESCE(SUM(input_tokens), 0) AS input_tokens,
                           COALESCE(SUM(output_tokens), 0) AS output_tokens
                    FROM llm_calls GROUP BY model ORDER BY calls DESC
                    """
                ).fetchall()
            ]
            by_agent = [
                dict(row)
                for row in conn.execute(
                    """
                    SELECT agent_name, COUNT(*) AS calls,
                           COALESCE(SUM(input_tokens), 0) AS input_tokens,
                           COALESCE(SUM(output_tokens), 0) AS output_tokens,
                           COALESCE(AVG(latency_ms), 0) AS average_latency_ms
                    FROM llm_calls GROUP BY agent_name ORDER BY calls DESC
                    """
                ).fetchall()
            ]
            daily = [
                dict(row)
                for row in conn.execute(
                    """
                    SELECT substr(timestamp_utc, 1, 10) AS day,
                           COUNT(*) AS calls,
                           COALESCE(SUM(input_tokens + output_tokens), 0) AS total_tokens
                    FROM llm_calls GROUP BY day ORDER BY day DESC LIMIT 30
                    """
                ).fetchall()
            ][::-1]
            recent_calls = [
                dict(row)
                for row in conn.execute(
                    "SELECT * FROM llm_calls ORDER BY timestamp_utc DESC LIMIT ?",
                    (recent_limit,),
                ).fetchall()
            ]
            app_counts = {
                "users": conn.execute("SELECT COUNT(*) FROM users").fetchone()[0],
                "conversations": conn.execute("SELECT COUNT(*) FROM conversations").fetchone()[0],
                "messages": conn.execute("SELECT COUNT(*) FROM messages").fetchone()[0],
                "feedback_total": conn.execute("SELECT COUNT(*) FROM feedback").fetchone()[0],
                "feedback_positive": conn.execute(
                    "SELECT COUNT(*) FROM feedback WHERE rating = 1"
                ).fetchone()[0],
                "feedback_negative": conn.execute(
                    "SELECT COUNT(*) FROM feedback WHERE rating = -1"
                ).fetchone()[0],
                "policy_cache_entries": conn.execute(
                    "SELECT COUNT(*) FROM policy_answer_cache"
                ).fetchone()[0],
                "policy_cache_hits": conn.execute(
                    "SELECT COALESCE(SUM(hit_count), 0) FROM policy_answer_cache"
                ).fetchone()[0],
            }
            payload_rows = conn.execute(
                "SELECT payload_json FROM messages WHERE role = 'assistant' AND payload_json IS NOT NULL"
            ).fetchall()

        decisions: dict[str, int] = {}
        for row in payload_rows:
            try:
                decision = json.loads(row["payload_json"]).get("decision", "unknown")
            except (json.JSONDecodeError, TypeError):
                decision = "unknown"
            decisions[decision] = decisions.get(decision, 0) + 1
        llm_totals["total_tokens"] = (
            llm_totals["input_tokens"] + llm_totals["output_tokens"]
        )
        return {
            "llm": llm_totals,
            "by_model": by_model,
            "by_agent": by_agent,
            "daily": daily,
            "recent_calls": recent_calls,
            "application": app_counts,
            "decisions": [
                {"decision": decision, "count": count}
                for decision, count in sorted(decisions.items())
            ],
        }
