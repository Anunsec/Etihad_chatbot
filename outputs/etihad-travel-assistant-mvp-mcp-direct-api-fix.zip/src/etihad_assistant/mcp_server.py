from __future__ import annotations

from .config import get_settings
from .flight_mcp import create_flight_mcp
from .flights import AviationStackProvider

mcp = create_flight_mcp(AviationStackProvider(get_settings()))


def run() -> None:
    mcp.run()


if __name__ == "__main__":
    run()
