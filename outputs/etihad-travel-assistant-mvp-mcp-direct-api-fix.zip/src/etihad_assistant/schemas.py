from __future__ import annotations

from datetime import date, datetime
from enum import StrEnum
from typing import Any, Literal

from pydantic import BaseModel, Field


class Role(StrEnum):
    user = "user"
    admin = "admin"


class Decision(StrEnum):
    answer = "answer"
    clarify = "clarify"
    not_found = "not_found"
    off_topic = "off_topic"
    tool_unavailable = "tool_unavailable"
    conflicting_policy = "conflicting_policy"


class UserPrincipal(BaseModel):
    id: str
    username: str
    role: Role


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: Role


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    conversation_id: str | None = None


class Citation(BaseModel):
    id: str
    source_type: Literal["policy", "flight_tool"]
    document_title: str
    section_path: str
    version_id: str
    effective_date_status: str = "not_stated"
    snapshot_page: int | None = None
    passage: str
    table_cell_ids: list[str] = Field(default_factory=list)
    canonical_url: str | None = None
    retrieved_at: datetime
    fixture: bool = False


class Claim(BaseModel):
    claim: str
    citation_ids: list[str]


class GroundedDraft(BaseModel):
    decision: Decision
    answer_markdown: str
    claims: list[Claim] = Field(default_factory=list)
    clarification_question: str | None = None
    refusal_reason: str | None = None


class ChatResponse(GroundedDraft):
    answer_id: str
    conversation_id: str
    citations: list[Citation] = Field(default_factory=list)
    state: dict[str, Any] = Field(default_factory=dict)
    trace_id: str


class FeedbackRequest(BaseModel):
    answer_id: str
    rating: Literal[-1, 1]
    reason_code: str | None = Field(default=None, max_length=80)
    free_text: str | None = Field(default=None, max_length=1000)


class FeedbackResponse(BaseModel):
    stored: bool
    feedback_id: str


class FlightStatusRequest(BaseModel):
    flight_number: str = Field(pattern=r"^[A-Za-z]{2}\s?\d{1,4}$")
    departure_date: date
    origin_iata: str | None = Field(default=None, pattern=r"^[A-Za-z]{3}$")


class FlightScheduleRequest(BaseModel):
    origin_iata: str = Field(pattern=r"^[A-Za-z]{3}$")
    destination_iata: str = Field(pattern=r"^[A-Za-z]{3}$")
    date: date


class RouteRequest(BaseModel):
    origin_iata: str | None = Field(default=None, pattern=r"^[A-Za-z]{3}$")
    destination_iata: str | None = Field(default=None, pattern=r"^[A-Za-z]{3}$")
    airline_iata: str = Field(default="EY", pattern=r"^[A-Za-z0-9]{2,3}$")
