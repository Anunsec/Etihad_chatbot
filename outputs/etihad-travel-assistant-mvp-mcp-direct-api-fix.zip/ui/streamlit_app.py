from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import httpx
import streamlit as st

API_URL = os.getenv("API_URL", "http://localhost:8000").rstrip("/")
LOGO_PATH = Path(__file__).resolve().parents[1] / "OIP.webp"


st.set_page_config(
    page_title="Etihad Travel Assistant — Demo",
    page_icon=str(LOGO_PATH),
    layout="wide",
)
logo_column, title_column = st.columns([1, 4], vertical_alignment="center")
with logo_column:
    st.image(str(LOGO_PATH), width="stretch")
with title_column:
    st.title("Etihad Passenger Travel Assistant")
st.info(
    "Policy answers are verbatim extracts retrieved locally from the Etihad Hub policy-library "
    "snapshot with no LLM call. AviationStack/MCP and non-RAG answers use OpenAI through "
    "LangChain/LangGraph."
)


def api_request(method: str, path: str, **kwargs: Any) -> httpx.Response:
    headers = kwargs.pop("headers", {})
    if st.session_state.get("token"):
        headers["Authorization"] = f"Bearer {st.session_state.token}"
    return httpx.request(method, f"{API_URL}{path}", headers=headers, timeout=60, **kwargs)


def reset_session() -> None:
    for key in ("token", "role", "messages", "conversation_id"):
        st.session_state.pop(key, None)


if "messages" not in st.session_state:
    st.session_state.messages = []

if not st.session_state.get("token"):
    st.subheader("Sign in")
    with st.form("login"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("Sign in", type="primary")
    if submitted:
        try:
            response = httpx.post(
                f"{API_URL}/auth/token",
                data={"username": username, "password": password},
                timeout=15,
            )
            response.raise_for_status()
            payload = response.json()
            st.session_state.token = payload["access_token"]
            st.session_state.role = payload["role"]
            st.rerun()
        except Exception as exc:
            st.error(f"Sign-in failed: {exc}")
    st.stop()

with st.sidebar:
    st.success(f"Signed in as **{st.session_state.role}**")
    page = (
        st.radio("View", ["Chat", "Admin dashboard"])
        if st.session_state.role == "admin"
        else "Chat"
    )
    if st.button("New conversation"):
        st.session_state.messages = []
        st.session_state.pop("conversation_id", None)
        st.rerun()
    if st.button("Sign out"):
        reset_session()
        st.rerun()



if page == "Admin dashboard":
    st.header("Admin observability dashboard")
    if st.button("Refresh dashboard", type="primary") or "admin_dashboard" not in st.session_state:
        try:
            dashboard_response = api_request("GET", "/admin/dashboard?limit=250")
            dashboard_response.raise_for_status()
            st.session_state.admin_dashboard = dashboard_response.json()
            audit_response = api_request("GET", "/admin/audit-logs?limit=250")
            audit_response.raise_for_status()
            st.session_state.audit_logs = audit_response.json()
        except Exception as exc:
            st.error(f"Could not load dashboard: {exc}")

    dashboard = st.session_state.get("admin_dashboard")
    if dashboard:
        config = dashboard["configuration"]
        st.caption(
            f"OpenAI: {'configured' if config['openai_configured'] else 'missing'} · "
            f"Model: {config['openai_model']} · "
            f"LangSmith: {'enabled' if config['langsmith_tracing'] else 'disabled'} · "
            f"AviationStack: {'configured' if config['aviationstack_configured'] else 'missing'}"
        )

        llm = dashboard["llm"]
        metric_columns = st.columns(5)
        metric_columns[0].metric("LLM calls", llm["total_calls"])
        metric_columns[1].metric("Successful", llm["successful_calls"])
        metric_columns[2].metric("Failed", llm["failed_calls"])
        metric_columns[3].metric("Total tokens", llm["total_tokens"])
        metric_columns[4].metric("Avg latency", f"{llm['average_latency_ms']:.0f} ms")

        token_columns = st.columns(4)
        token_columns[0].metric("Input tokens", llm["input_tokens"])
        token_columns[1].metric("Output tokens", llm["output_tokens"])
        token_columns[2].metric("Cached input", llm["cached_input_tokens"])
        token_columns[3].metric("Reasoning tokens", llm["reasoning_tokens"])

        st.subheader("Usage over time")
        if dashboard["daily"]:
            st.bar_chart(dashboard["daily"], x="day", y=["calls", "total_tokens"])
        else:
            st.info("No LLM calls have been recorded yet.")

        chart_left, chart_right = st.columns(2)
        with chart_left:
            st.subheader("By model")
            st.dataframe(dashboard["by_model"], use_container_width=True, hide_index=True)
        with chart_right:
            st.subheader("By graph node")
            st.dataframe(dashboard["by_agent"], use_container_width=True, hide_index=True)

        app = dashboard["application"]
        st.subheader("Application activity")
        app_columns = st.columns(6)
        for column, (label, key) in zip(
            app_columns,
            [
                ("Users", "users"),
                ("Conversations", "conversations"),
                ("Messages", "messages"),
                ("Feedback", "feedback_total"),
                ("Positive", "feedback_positive"),
                ("Negative", "feedback_negative"),
            ],
            strict=True,
        ):
            column.metric(label, app[key])
        st.dataframe(dashboard["decisions"], use_container_width=True, hide_index=True)

        st.subheader("Policy answer cache")
        cache_columns = st.columns(2)
        cache_columns[0].metric("Cached answers", app["policy_cache_entries"])
        cache_columns[1].metric("Cache hits (no new LLM call)", app["policy_cache_hits"])

        st.subheader("Recent LLM calls")
        safe_calls = [
            {
                key: value
                for key, value in row.items()
                if key not in {"user_id", "conversation_id"}
            }
            for row in dashboard["recent_calls"]
        ]
        st.dataframe(safe_calls, use_container_width=True, hide_index=True)

        audit_logs = st.session_state.get("audit_logs", [])
        st.subheader("Recent audit events")
        st.dataframe(audit_logs, use_container_width=True, hide_index=True)
        download_left, download_right = st.columns(2)
        download_left.download_button(
            "Download LLM usage JSON",
            data=json.dumps(dashboard, indent=2),
            file_name="llm-usage-dashboard.json",
            mime="application/json",
        )
        download_right.download_button(
            "Download audit JSON",
            data=json.dumps(audit_logs, indent=2),
            file_name="audit-log.json",
            mime="application/json",
        )
    st.stop()


for index, item in enumerate(st.session_state.messages):
    with st.chat_message(item["role"]):
        st.markdown(item["content"])
        if item["role"] == "assistant":
            st.caption(f"Decision: {item.get('decision', 'unknown')}")
            for citation in item.get("citations", []):
                with st.expander(f"Source: {citation['section_path']}"):
                    st.markdown(f"**Document:** {citation['document_title']}")
                    st.markdown(f"**Version:** {citation['version_id']}")
                    if citation.get("canonical_url"):
                        st.markdown(f"[Open live source]({citation['canonical_url']})")
                    if citation.get("snapshot_page"):
                        st.markdown(f"**Snapshot page:** {citation['snapshot_page']}")
                    st.code(citation["passage"])
                    if citation.get("table_cell_ids"):
                        st.caption("Cells: " + ", ".join(citation["table_cell_ids"]))
            col_up, col_down, _ = st.columns([1, 1, 8])
            if col_up.button("👍", key=f"up-{index}"):
                api_request(
                    "POST",
                    "/feedback",
                    json={"answer_id": item["answer_id"], "rating": 1},
                )
                st.toast("Feedback saved")
            if col_down.button("👎", key=f"down-{index}"):
                api_request(
                    "POST",
                    "/feedback",
                    json={"answer_id": item["answer_id"], "rating": -1},
                )
                st.toast("Feedback saved")


if prompt := st.chat_input("Ask about any Etihad Hub policy or live flight data"):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)
    with st.chat_message("assistant"):
        try:
            response = api_request(
                "POST",
                "/chat",
                json={
                    "message": prompt,
                    "conversation_id": st.session_state.get("conversation_id"),
                },
            )
            response.raise_for_status()
            result = response.json()
            st.session_state.conversation_id = result["conversation_id"]
            st.markdown(result["answer_markdown"])
            st.session_state.messages.append(
                {
                    "role": "assistant",
                    "content": result["answer_markdown"],
                    "decision": result["decision"],
                    "citations": result["citations"],
                    "answer_id": result["answer_id"],
                }
            )
            st.rerun()
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 401:
                reset_session()
                st.error("Your session expired. Please sign in again.")
            else:
                st.error(exc.response.text)
        except Exception as exc:
            st.error(f"Backend unavailable: {exc}")
