from __future__ import annotations

import asyncio
import json
from datetime import date
from typing import Any

from fastmcp import FastMCP
from langchain.mcp import MCPAdapter

from .flights import FlightProvider


def create_flight_mcp(provider: FlightProvider) -> FastMCP:
    """Create the AviationStack MCP server used by both the app and CLI server."""
    server = FastMCP("AviationStack Flight Data")

    @server.tool()
    def get_flight_status(
        flight_number: str, departure_date: str, origin_iata: str | None = None
    ) -> dict[str, Any]:
        """Return normalized AviationStack flight status; accepts no passenger data."""
        return provider.get_flight_status(
            flight_number=flight_number,
            departure_date=date.fromisoformat(departure_date),
            origin_iata=origin_iata,
        )

    @server.tool()
    def list_airport_arrivals(airport_iata: str) -> dict[str, Any]:
        """Return the current AviationStack airport arrivals board; no synthetic flights."""
        return provider.list_airport_arrivals(airport_iata)

    @server.tool()
    def search_flight_schedule(
        origin_iata: str, destination_iata: str, travel_date: str
    ) -> dict[str, Any]:
        """Return normalized AviationStack schedule data; accepts no passenger data."""
        return provider.search_flight_schedule(
            origin_iata=origin_iata,
            destination_iata=destination_iata,
            travel_date=date.fromisoformat(travel_date),
        )

    @server.tool()
    def list_routes(
        origin_iata: str | None = None,
        destination_iata: str | None = None,
        airline_iata: str = "EY",
    ) -> dict[str, Any]:
        """Return normalized AviationStack route data; accepts no passenger data."""
        return provider.list_routes(origin_iata, destination_iata, airline_iata)

    return server


def _normalise_tool_result(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, dict):
                return parsed
        except json.JSONDecodeError:
            pass
        return {"status": "error", "notice": value}
    if isinstance(value, list):
        text_parts: list[str] = []
        for item in value:
            if isinstance(item, dict) and isinstance(item.get("text"), str):
                text_parts.append(item["text"])
            elif isinstance(getattr(item, "text", None), str):
                text_parts.append(item.text)
        if text_parts:
            return _normalise_tool_result("\n".join(text_parts))
    content = getattr(value, "content", None)
    if isinstance(content, str):
        return _normalise_tool_result(content)
    return {"status": "error", "notice": f"Unexpected MCP result: {type(value).__name__}"}


async def invoke_flight_mcp(
    provider: FlightProvider, tool_name: str, arguments: dict[str, Any]
) -> dict[str, Any]:
    server = create_flight_mcp(provider)
    async with MCPAdapter(server) as adapter:
        tools = {tool.name: tool for tool in await adapter.list_tools()}
        if tool_name not in tools:
            return {"status": "error", "notice": f"MCP tool {tool_name} is unavailable"}
        return _normalise_tool_result(await tools[tool_name].ainvoke(arguments))


def invoke_flight_mcp_sync(
    provider: FlightProvider, tool_name: str, arguments: dict[str, Any]
) -> dict[str, Any]:
    return asyncio.run(invoke_flight_mcp(provider, tool_name, arguments))
