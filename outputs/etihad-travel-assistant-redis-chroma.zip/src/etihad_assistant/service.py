from __future__ import annotations

import os
import time
from datetime import datetime
from uuid import uuid4

from langsmith import traceable

from .audit import AuditLogger
from .cache import PolicyAnswerCache
from .chroma_retrieval import ChromaPolicyRepository
from .config import Settings
from .db import Database
from .flights import AviationStackProvider
from .graph import build_graph
from .retrieval import PolicyRepository
from .schemas import ChatRequest, ChatResponse, Citation, UserPrincipal


class AssistantService:
    def __init__(self, settings: Settings, database: Database):
        self.settings = settings
        self.database = database
        self.audit = AuditLogger(settings.audit_file)
        self.rag_warning: str | None = None
        if settings.rag_backend == "chroma":
            try:
                self.repository = ChromaPolicyRepository(settings)
            except Exception:
                self.repository = PolicyRepository(settings)
                self.rag_warning = "Chroma initialization failed; using local BM25 retrieval."
        else:
            self.repository = PolicyRepository(settings)
        self.cache = PolicyAnswerCache(settings, database)
        if settings.langsmith_tracing:
            os.environ["LANGSMITH_TRACING"] = "true"
            os.environ["LANGSMITH_PROJECT"] = settings.langsmith_project
            if settings.langsmith_api_key:
                os.environ["LANGSMITH_API_KEY"] = settings.langsmith_api_key
        provider = AviationStackProvider(settings)
        self.graph = build_graph(self.repository, provider, settings, database, self.cache)

    @traceable(name="etihad_chat_turn", run_type="chain")
    def chat(self, request: ChatRequest, user: UserPrincipal) -> ChatResponse:
        started = time.perf_counter()
        conversation_id, app_state = self.database.load_or_create_conversation(
            request.conversation_id, user.id
        )
        turn_id = str(uuid4())
        trace_id = str(uuid4())
        recent = self.database.recent_messages(
            conversation_id, user.id, self.settings.chat_history_messages
        )
        self.database.add_message(conversation_id, "user", request.message)
        result = self.graph.invoke(
            {
                "message": request.message,
                "conversation_id": conversation_id,
                "user_id": user.id,
                "turn_id": turn_id,
                "trace_id": trace_id,
                "app_state": app_state,
                "conversation_history": recent,
            },
            config={
                "run_name": "etihad-passenger-turn",
                "tags": ["local-mvp", user.role.value],
                "metadata": {
                    "conversation_id": conversation_id,
                    "turn_id": turn_id,
                    "user_role": user.role.value,
                },
            },
        )
        draft = result["draft"]
        updated_state = result.get("app_state", app_state)
        self.database.save_conversation_state(conversation_id, updated_state)

        citations: list[Citation] = []
        referenced = {citation_id for claim in draft.claims for citation_id in claim.citation_ids}
        for chunk in result.get("retrieved", []):
            if chunk.id in referenced:
                citations.append(chunk.as_citation())
        if "aviationstack-live" in referenced:
            flight_result = result["flight_result"]
            citations.append(
                Citation(
                    id="aviationstack-live",
                    source_type="flight_tool",
                    document_title="AviationStack",
                    section_path="Normalized live flight-data response",
                    version_id="aviationstack-api-v1",
                    passage=str(flight_result),
                    retrieved_at=datetime.fromisoformat(flight_result["retrieved_at"]),
                    fixture=False,
                )
            )

        answer_id = str(uuid4())
        response = ChatResponse(
            **draft.model_dump(),
            answer_id=answer_id,
            conversation_id=conversation_id,
            citations=citations,
            state=updated_state,
            trace_id=trace_id,
        )
        self.database.add_message(
            conversation_id,
            "assistant",
            response.answer_markdown,
            response.model_dump(mode="json"),
            message_id=answer_id,
        )
        self.audit.write(
            "chat_turn",
            trace_id=trace_id,
            conversation_id=conversation_id,
            turn_id=turn_id,
            user_id=user.id,
            role=user.role.value,
            intent=result.get("intent"),
            decision=response.decision.value,
            citation_ids=[item.id for item in citations],
            retrieval=result.get("retrieval_details", {}),
            latency_ms=round((time.perf_counter() - started) * 1000, 2),
        )
        return response
