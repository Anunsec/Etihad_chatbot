from __future__ import annotations

import json
from typing import Any
from urllib.parse import urlsplit

from .config import Settings
from .db import Database


class PolicyAnswerCache:
    """Shared Redis cache with a durable local fallback; never expose connection secrets."""

    PREFIX = "etihad:policy-answer:v1:"
    HITS_KEY = "etihad:policy-answer:v1-hits"

    def __init__(self, settings: Settings, database: Database, redis_client: Any = None):
        self.settings = settings
        self.database = database
        self.client = redis_client
        self.backend = "sqlite"
        self.warning: str | None = None
        if redis_client is not None:
            self.backend = "redis"
        elif settings.redis_url:
            parsed = urlsplit(settings.redis_url)
            local = parsed.hostname in {"localhost", "127.0.0.1", "::1"}
            if parsed.scheme not in {"redis", "rediss"}:
                self.warning = "Redis URL must use redis:// or rediss://. Using SQLite cache."
            elif settings.redis_require_tls and parsed.scheme != "rediss" and not local:
                self.warning = "Remote Redis requires TLS (rediss://). Using SQLite cache."
            else:
                try:
                    import redis

                    self.client = redis.Redis.from_url(
                        settings.redis_url,
                        decode_responses=True,
                        socket_connect_timeout=3,
                        socket_timeout=3,
                    )
                    self.client.ping()
                    self.backend = "redis"
                except Exception:
                    self.client = None
                    self.warning = "Redis unavailable. Using SQLite cache."

    def get(self, key: str) -> tuple[dict[str, Any] | None, str]:
        if self.client is not None:
            try:
                raw = self.client.get(self.PREFIX + key)
                if raw:
                    value = json.loads(raw)
                    if isinstance(value, dict) and {"draft", "source_ids"} <= value.keys():
                        self.client.incr(self.HITS_KEY)
                        return value, "redis"
                return None, "redis"
            except Exception:
                self.warning = "Redis request failed. Using SQLite cache."
        return self.database.get_cached_policy_answer(key), "sqlite"

    def put(self, key: str, draft: dict[str, Any], source_ids: list[str]) -> str:
        if self.client is not None:
            try:
                self.client.setex(
                    self.PREFIX + key,
                    self.settings.redis_cache_ttl_seconds,
                    json.dumps({"draft": draft, "source_ids": source_ids}, ensure_ascii=False),
                )
                return "redis"
            except Exception:
                self.warning = "Redis request failed. Using SQLite cache."
        self.database.put_cached_policy_answer(key, draft, source_ids)
        return "sqlite"

    def stats(self) -> dict[str, Any]:
        if self.client is not None:
            try:
                entries = sum(1 for _ in self.client.scan_iter(match=self.PREFIX + "*"))
                return {
                    "backend": "redis",
                    "entries": entries,
                    "hits": int(self.client.get(self.HITS_KEY) or 0),
                    "ttl_seconds": self.settings.redis_cache_ttl_seconds,
                    "warning": self.warning,
                }
            except Exception:
                self.warning = "Redis metrics unavailable; showing SQLite fallback metrics."
        application = self.database.admin_dashboard(1)["application"]
        return {
            "backend": "sqlite",
            "entries": application["policy_cache_entries"],
            "hits": application["policy_cache_hits"],
            "warning": self.warning,
        }
