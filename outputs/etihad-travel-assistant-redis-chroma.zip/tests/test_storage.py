from __future__ import annotations

import hashlib
import json
from pathlib import Path

from etihad_assistant.cache import PolicyAnswerCache
from etihad_assistant.chroma_retrieval import ChromaPolicyRepository
from etihad_assistant.config import PROJECT_ROOT, Settings
from etihad_assistant.db import Database


class FakeRedis:
    def __init__(self):
        self.values = {}
        self.ttls = {}

    def get(self, key):
        return self.values.get(key)

    def setex(self, key, ttl, value):
        self.values[key] = value
        self.ttls[key] = ttl

    def incr(self, key):
        self.values[key] = str(int(self.values.get(key, 0)) + 1)

    def scan_iter(self, match):
        prefix = match.rstrip("*")
        return (key for key in self.values if key.startswith(prefix))


class FakeEmbeddings:
    def __init__(self):
        self.document_batches = 0
        self.queries = 0

    @staticmethod
    def vector(text):
        digest = hashlib.sha256(text.lower().encode()).digest()
        return [value / 255 for value in digest[:8]]

    def embed_documents(self, texts):
        self.document_batches += 1
        return [self.vector(text) for text in texts]

    def embed_query(self, text):
        self.queries += 1
        return self.vector(text)


def test_shared_redis_cache_and_tls_guard(tmp_path: Path):
    settings = Settings(
        database_path=tmp_path / "test.db",
        redis_url="redis://default:placeholder@example.invalid:6379",
    )
    db = Database(settings)
    db.initialize()
    guarded = PolicyAnswerCache(settings, db)
    assert guarded.backend == "sqlite"
    assert "TLS" in guarded.warning

    client = FakeRedis()
    cache = PolicyAnswerCache(settings, db, redis_client=client)
    assert cache.put("abc", {"answer_markdown": "policy"}, ["source"]) == "redis"
    assert json.loads(client.values[cache.PREFIX + "abc"])["source_ids"] == ["source"]
    assert client.ttls[cache.PREFIX + "abc"] == settings.redis_cache_ttl_seconds
    another_instance = PolicyAnswerCache(settings, db, redis_client=client)
    value, backend = another_instance.get("abc")
    assert backend == "redis"
    assert value["draft"]["answer_markdown"] == "policy"
    assert another_instance.stats()["hits"] == 1


def test_chroma_policy_index_persists_without_reembedding(tmp_path: Path):
    settings = Settings(
        openai_api_key="test-key",
        policy_corpus_path=PROJECT_ROOT / "data/corpus/etihad_hub_policy_library.json",
        chroma_persist_directory=tmp_path / "chroma",
    )
    first_embeddings = FakeEmbeddings()
    first = ChromaPolicyRepository(settings, embeddings=first_embeddings)
    chunks, details = first.retrieve("What is the pets in cabin policy?")
    assert chunks
    assert details["backend"] == "chroma_hybrid"
    assert first.collection.count() == len([chunk for chunk in first.chunks if chunk.is_current])
    assert first_embeddings.document_batches > 0

    second_embeddings = FakeEmbeddings()
    second = ChromaPolicyRepository(settings, embeddings=second_embeddings)
    second.retrieve("What is the pets in cabin policy?")
    assert second_embeddings.document_batches == 0
    assert second_embeddings.queries == 1


def test_chat_history_is_scoped_to_conversation_owner(tmp_path: Path):
    settings = Settings(database_path=tmp_path / "test.db")
    db = Database(settings)
    db.initialize()
    user = db.authenticate(settings.demo_user_username, settings.demo_user_password)
    admin = db.authenticate(settings.demo_admin_username, settings.demo_admin_password)
    assert user and admin
    conversation, _ = db.load_or_create_conversation(None, user.id)
    db.add_message(conversation, "user", "My baggage question")
    db.add_message(conversation, "assistant", "Policy answer")
    assert [item["content"] for item in db.recent_messages(conversation, user.id)] == [
        "My baggage question", "Policy answer"
    ]
    assert db.recent_messages(conversation, admin.id) == []
